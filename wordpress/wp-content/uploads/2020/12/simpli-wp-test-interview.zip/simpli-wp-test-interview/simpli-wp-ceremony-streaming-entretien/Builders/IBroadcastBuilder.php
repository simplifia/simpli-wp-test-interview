<?php
/**
 * Created by PhpStorm.
 * User: benoit
 * Date: 24/07/18
 * Time: 15:44
 */

namespace SimpliCeremonyStreamingPlugin\Builders;


interface IBroadcastBuilder {
}